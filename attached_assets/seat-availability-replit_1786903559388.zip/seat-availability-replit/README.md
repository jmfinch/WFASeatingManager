# Seating Availability

Real-time seat-availability tool for a 3-section auditorium (Whitefish Assembly).
Two screens sharing one live data set:

- **Host Controls** — an iPad-style view where a seating host taps seats to
  mark them open/full. Supports pinch-zoom, drag-to-pan, and jump-to-full-room.
- **Display** — a read-only, auto-fit view meant for a lobby/entrance TV,
  showing live seat availability plus a customizable welcome message.

Also included: a Setup screen (room dimensions, colors, welcome message,
gathering names, baseline row counts), a History screen (archived gatherings
with per-gathering or trend analysis via Claude), and a "Submit Final" flow
that archives a gathering's full seat-marking event log and resets for the
next one.

## How it's built

- **Frontend**: React 18 + Vite, styled with Tailwind (loaded via CDN in
  `index.html` — no build-step Tailwind config, keeps things simple for a
  small internal tool).
- **Backend**: a small Express server (`server/index.js`) that does two jobs:
  1. A key-value storage API (`/api/storage/:key`) backed by a JSON file on
     disk (`server/data.json`). This replaced Claude's artifact-only
     `window.storage` API when the app moved off claude.ai — same shape
     (get/set/delete by key), just backed by a real server instead.
  2. A proxy endpoint (`/api/analyze`) that calls the real Anthropic API using
     a server-side API key, so the key is never exposed to the browser. Used
     by the History screen's "Analyze with Claude" button.
- Everything (layout, live seat state, baseline, gathering history) is stored
  under a handful of keys — see `STORAGE_LAYOUT_KEY`, `STORAGE_STATE_KEY`,
  `STORAGE_BASELINE_KEY`, `STORAGE_HISTORY_INDEX_KEY`, and `history:<id>` near
  the top of `src/App.jsx`.

## Running on Replit

1. Import this project (upload the zip, or push it to a GitHub repo first and
   import from there).
2. Add your Anthropic API key: **Tools → Secrets**, add a secret named
   `ANTHROPIC_API_KEY`. (Only needed for the "Analyze with Claude" button in
   History — everything else works without it.)
3. Click **Run**. This runs `npm run build && npm run start`, which builds
   the frontend into `dist/` and starts the Express server on port 3000,
   which Replit maps to your public URL automatically.
4. Open the URL on the iPad → that's Host Controls. Open it on whatever's
   driving the lobby TV → tap the TV icon to switch to Display mode.

There's no login wall and no publish/version-selector step anymore — editing
the code and hitting Run (or redeploying) updates the live URL directly.

## Running locally / in dev

```
npm install
npm run dev        # starts Vite on :5173 (frontend only, hot reload)
```

In a second terminal:
```
node server/index.js   # starts the API server on :3000
```

Vite's dev server proxies `/api/*` to `localhost:3000` (see `vite.config.js`),
so the frontend on :5173 talks to the real backend during development.

## Making changes

The whole app lives in one file: `src/App.jsx`. Rough map, top to bottom:

- Storage helpers (`loadLayout`, `saveState`, etc.) — talk to the backend.
- Geometry math (`computeGeometry`) — figures out the actual pixel layout of
  the 3 sections, including the angled outer sections' true rotated bounding
  box (this was a real bug once — the angled sections can swing outside their
  own unrotated rectangle, so naive width/height math clips them).
- `SetupScreen`, `RoomCanvas`, `ZoomPane` (pan/pinch-zoom for Host Controls),
  `DisplayScreen` (auto-fits the whole room to the TV screen), `HistoryScreen`
  (archived gatherings + on-demand Claude analysis).
- `App` — top-level state, the debounced/serialized save logic (`commitSeatStatus`
  / `flushSave` — this exists specifically to prevent rapid taps from racing
  each other and reverting), and the `submitFinal` archive-and-reset flow.

Known context worth knowing before asking for changes:
- Seat IDs are `<L|C|R>-r<row>-s<seat>`, e.g. `C-r3-s5`.
- Row counts are independent per section (left/center/right can each have a
  different number of rows).
- The "extra rows" feature compares today's row counts against a saved
  baseline (set via a button in Setup) — it's automatic, not manually logged.
- Panning on Host Controls uses native touch scrolling on touch devices
  (smoothest option) and custom drag-to-pan only for mouse — don't
  reintroduce manual scrollLeft mutation for touch, it was previously janky.
