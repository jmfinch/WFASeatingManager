import express from 'express';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, 'data.json');
const DIST_DIR = path.join(__dirname, '..', 'dist');

const app = express();
app.use(express.json({ limit: '10mb' }));

// ---------- tiny file-backed key-value store ----------
// Everything the app needs (layout, live seat state, baseline, history) goes
// through this. Kept in memory for speed, persisted to disk on every write so
// data survives a restart. Writes are serialized through `writeQueue` so two
// requests landing close together can't corrupt the file by writing at once —
// this is the server-side equivalent of the in-flight/queued save guard the
// app already uses on the client for the same reason.
let store = {};
let writeQueue = Promise.resolve();

async function loadStore() {
  try {
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    store = JSON.parse(raw);
  } catch {
    store = {};
  }
}

function persist() {
  writeQueue = writeQueue.then(() =>
    fs.writeFile(DATA_FILE, JSON.stringify(store)).catch((e) => console.error('persist failed', e))
  );
  return writeQueue;
}

await loadStore();

app.get('/api/storage', (req, res) => {
  const prefix = req.query.prefix || '';
  const keys = Object.keys(store).filter((k) => k.startsWith(prefix));
  res.json({ keys });
});

app.get('/api/storage/:key', (req, res) => {
  const key = req.params.key;
  if (!(key in store)) return res.status(404).json({ error: 'not found' });
  res.json({ key, value: store[key] });
});

app.post('/api/storage/:key', async (req, res) => {
  const key = req.params.key;
  const { value } = req.body;
  store[key] = value;
  await persist();
  res.json({ key, value });
});

app.delete('/api/storage/:key', async (req, res) => {
  const key = req.params.key;
  delete store[key];
  await persist();
  res.json({ key, deleted: true });
});

// ---------- Claude analysis proxy ----------
// Keeps the real Anthropic API key on the server (set it as a Replit Secret
// named ANTHROPIC_API_KEY) instead of ever sending it to the browser.
app.post('/api/analyze', async (req, res) => {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(400).json({ error: 'ANTHROPIC_API_KEY is not set. Add it in Replit under Secrets.' });
  }
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: 'Missing prompt' });

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json(data);
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ---------- serve the built frontend ----------
app.use(express.static(DIST_DIR));
app.get('*', (req, res) => {
  res.sendFile(path.join(DIST_DIR, 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Seating Availability server running on port ${PORT}`);
});
